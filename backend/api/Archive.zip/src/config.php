<?php

return array(
  'secretKey' => 'secret',
  'users' => [
      'admin' => 'admin',
  ]
);
